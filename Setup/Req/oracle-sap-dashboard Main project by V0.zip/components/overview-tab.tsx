"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Database, CheckCircle, XCircle, Clock, Activity } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const statsData = [
  {
    title: "Total Records",
    value: "125",
    change: "+12%",
    trend: "up",
    icon: Database,
    color: "text-blue-600",
  },
  {
    title: "Synced Records",
    value: "120",
    change: "+8%",
    trend: "up",
    icon: CheckCircle,
    color: "text-green-600",
  },
  {
    title: "Failed Records",
    value: "5",
    change: "-2%",
    trend: "down",
    icon: XCircle,
    color: "text-red-600",
  },
  {
    title: "Pending Records",
    value: "0",
    change: "0%",
    trend: "neutral",
    icon: Clock,
    color: "text-yellow-600",
  },
]

const syncHistoryData = [
  { date: "Jan 1", synced: 45, failed: 2 },
  { date: "Jan 2", synced: 52, failed: 1 },
  { date: "Jan 3", synced: 48, failed: 3 },
  { date: "Jan 4", synced: 61, failed: 1 },
  { date: "Jan 5", synced: 55, failed: 2 },
  { date: "Jan 6", synced: 67, failed: 0 },
  { date: "Jan 7", synced: 58, failed: 1 },
]

const distributionData = [
  { name: "Synced", value: 120, color: "#22c55e" },
  { name: "Failed", value: 5, color: "#ef4444" },
]

export function OverviewTab() {
  const successRate = Math.round((120 / 125) * 100)

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold tracking-tight">Overview</h3>
        <p className="text-muted-foreground">Monitor your Oracle to SAP B1 billing integration performance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statsData.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center text-xs text-muted-foreground">
                {stat.trend === "up" && <TrendingUp className="h-3 w-3 text-green-600 mr-1" />}
                {stat.trend === "down" && <TrendingDown className="h-3 w-3 text-red-600 mr-1" />}
                <span className={stat.trend === "up" ? "text-green-600" : stat.trend === "down" ? "text-red-600" : ""}>
                  {stat.change}
                </span>
                <span className="ml-1">from last period</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        {/* Sync History Chart */}
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Sync History</CardTitle>
            <CardDescription>Daily sync performance over the last 7 days</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={syncHistoryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="synced" stroke="#22c55e" strokeWidth={2} name="Synced" />
                <Line type="monotone" dataKey="failed" stroke="#ef4444" strokeWidth={2} name="Failed" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* System Health */}
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>System Health</CardTitle>
            <CardDescription>Overall integration performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex items-center justify-center">
                <div className="relative">
                  <ResponsiveContainer width={200} height={200}>
                    <PieChart>
                      <Pie
                        data={distributionData}
                        cx={100}
                        cy={100}
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {distributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{successRate}%</div>
                      <div className="text-xs text-muted-foreground">Success Rate</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Success Rate</span>
                  <Badge
                    variant="secondary"
                    className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                  >
                    Excellent
                  </Badge>
                </div>
                <Progress value={successRate} className="h-2" />

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Synced: 120</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Failed: 5</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recent Activity
          </CardTitle>
          <CardDescription>Latest sync operations and system events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { time: "2 minutes ago", action: "Sync completed successfully", status: "success", records: 15 },
              { time: "1 hour ago", action: "Failed to sync invoice INV-2024-001", status: "error", records: 1 },
              { time: "3 hours ago", action: "Scheduled sync started", status: "info", records: 25 },
              { time: "6 hours ago", action: "Configuration updated", status: "info", records: 0 },
            ].map((activity, index) => (
              <div key={index} className="flex items-center justify-between py-2 border-b last:border-b-0">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      activity.status === "success"
                        ? "bg-green-500"
                        : activity.status === "error"
                          ? "bg-red-500"
                          : "bg-blue-500"
                    }`}
                  />
                  <div>
                    <p className="text-sm font-medium">{activity.action}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
                {activity.records > 0 && <Badge variant="outline">{activity.records} records</Badge>}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
