"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Filter, Download, RefreshCw, AlertTriangle, Info, CheckCircle, XCircle } from "lucide-react"

interface LogEntry {
  id: string
  timestamp: string
  level: "info" | "warning" | "error" | "success"
  message: string
  details?: string
  source: string
}

const initialLogs: LogEntry[] = [
  {
    id: "1",
    timestamp: "2024-01-15 14:30:25",
    level: "success",
    message: "Invoice INV-2024-008 synced successfully to SAP B1",
    source: "SyncService",
    details: "Record processed in 1.2s",
  },
  {
    id: "2",
    timestamp: "2024-01-15 14:29:45",
    level: "error",
    message: "Failed to sync invoice INV-2024-003 - Connection timeout",
    source: "SyncService",
    details: "Error Code: CONN_TIMEOUT_001\nStack: Connection to SAP B1 server timed out after 30 seconds",
  },
  {
    id: "3",
    timestamp: "2024-01-15 14:28:12",
    level: "info",
    message: "Starting scheduled sync process",
    source: "Scheduler",
    details: "Processing 25 pending records",
  },
  {
    id: "4",
    timestamp: "2024-01-15 14:25:33",
    level: "warning",
    message: "High memory usage detected - 85% of allocated memory in use",
    source: "SystemMonitor",
    details: "Consider increasing memory allocation or optimizing queries",
  },
  {
    id: "5",
    timestamp: "2024-01-15 14:20:15",
    level: "success",
    message: "Database connection established successfully",
    source: "DatabaseService",
    details: "Connected to Oracle database in 0.8s",
  },
]

export function LogsTab() {
  const [logs, setLogs] = useState<LogEntry[]>(initialLogs)
  const [searchTerm, setSearchTerm] = useState("")
  const [levelFilter, setLevelFilter] = useState("all")
  const [autoRefresh, setAutoRefresh] = useState(true)

  // Simulate real-time log updates
  useEffect(() => {
    if (!autoRefresh) return

    const interval = setInterval(() => {
      const newLog: LogEntry = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleString("en-US", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
        level:
          Math.random() > 0.7 ? "error" : Math.random() > 0.5 ? "warning" : Math.random() > 0.3 ? "success" : "info",
        message: [
          "Invoice sync completed successfully",
          "Connection to SAP B1 established",
          "Failed to process record - validation error",
          "Memory usage within normal limits",
          "Scheduled task executed",
          "Database query optimization completed",
        ][Math.floor(Math.random() * 6)],
        source: ["SyncService", "DatabaseService", "Scheduler", "SystemMonitor"][Math.floor(Math.random() * 4)],
      }

      setLogs((prev) => [newLog, ...prev].slice(0, 100)) // Keep only last 100 logs
    }, 5000)

    return () => clearInterval(interval)
  }, [autoRefresh])

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.source.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesLevel = levelFilter === "all" || log.level === levelFilter
    return matchesSearch && matchesLevel
  })

  const getLevelIcon = (level: string) => {
    switch (level) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-600" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "info":
        return <Info className="h-4 w-4 text-blue-600" />
      default:
        return <Info className="h-4 w-4 text-gray-600" />
    }
  }

  const getLevelBadge = (level: string) => {
    const variants = {
      success: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      error: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
      warning: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
      info: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    }

    return (
      <Badge className={variants[level as keyof typeof variants] || "bg-gray-100 text-gray-800"}>
        {level.toUpperCase()}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold tracking-tight">Logs & Errors</h3>
        <p className="text-muted-foreground">Real-time system logs and error tracking for the integration</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>System Logs</span>
            <div className="flex items-center gap-2">
              <Badge variant={autoRefresh ? "default" : "secondary"} className="text-xs">
                {autoRefresh ? "Live" : "Paused"}
              </Badge>
              <Button variant="outline" size="sm" onClick={() => setAutoRefresh(!autoRefresh)}>
                {autoRefresh ? "Pause" : "Resume"}
              </Button>
            </div>
          </CardTitle>
          <CardDescription>Monitor system events, errors, and sync operations in real-time</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters and Search */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="info">Info</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="flex items-center gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button variant="outline" size="icon">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

          {/* Log Stream */}
          <ScrollArea className="h-[600px] w-full rounded-md border p-4">
            <div className="space-y-4">
              {filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div className="flex-shrink-0 mt-1">{getLevelIcon(log.level)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm font-mono text-muted-foreground">{log.timestamp}</span>
                      {getLevelBadge(log.level)}
                      <Badge variant="outline" className="text-xs">
                        {log.source}
                      </Badge>
                    </div>
                    <p className="text-sm font-medium mb-1">{log.message}</p>
                    {log.details && (
                      <pre className="text-xs text-muted-foreground bg-muted p-2 rounded mt-2 overflow-x-auto">
                        {log.details}
                      </pre>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
            <span>Showing {filteredLogs.length} log entries</span>
            <span>Auto-refresh: {autoRefresh ? "ON" : "OFF"}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
