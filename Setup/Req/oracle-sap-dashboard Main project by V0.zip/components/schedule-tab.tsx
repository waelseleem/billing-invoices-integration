"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Clock, Play, Pause, Settings, Calendar, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function ScheduleTab() {
  const [isEnabled, setIsEnabled] = useState(true)
  const [cronExpression, setCronExpression] = useState("0 */6 * * *")
  const [timezone, setTimezone] = useState("UTC")
  const [retryAttempts, setRetryAttempts] = useState("3")
  const [retryDelay, setRetryDelay] = useState("5")

  const schedulePresets = [
    { label: "Every 15 minutes", value: "*/15 * * * *" },
    { label: "Every hour", value: "0 * * * *" },
    { label: "Every 6 hours", value: "0 */6 * * *" },
    { label: "Daily at midnight", value: "0 0 * * *" },
    { label: "Daily at 9 AM", value: "0 9 * * *" },
    { label: "Weekly (Sunday)", value: "0 0 * * 0" },
  ]

  const getNextRunTime = () => {
    // This would normally calculate based on the cron expression
    const now = new Date()
    const nextRun = new Date(now.getTime() + 6 * 60 * 60 * 1000) // 6 hours from now
    return nextRun.toLocaleString()
  }

  const getLastRunStatus = () => {
    return {
      time: "2024-01-15 14:30:00",
      status: "success",
      recordsProcessed: 25,
      duration: "2.3s",
    }
  }

  const lastRun = getLastRunStatus()

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold tracking-tight">Schedule Configuration</h3>
        <p className="text-muted-foreground">Configure automated sync schedules and retry policies</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Schedule Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Sync Schedule
            </CardTitle>
            <CardDescription>Configure when the sync process should run automatically</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base">Enable Scheduled Sync</Label>
                <div className="text-sm text-muted-foreground">Automatically sync data at specified intervals</div>
              </div>
              <Switch checked={isEnabled} onCheckedChange={setIsEnabled} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="preset">Quick Presets</Label>
              <Select onValueChange={setCronExpression}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a preset schedule" />
                </SelectTrigger>
                <SelectContent>
                  {schedulePresets.map((preset) => (
                    <SelectItem key={preset.value} value={preset.value}>
                      {preset.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cron">Cron Expression</Label>
              <Input
                id="cron"
                value={cronExpression}
                onChange={(e) => setCronExpression(e.target.value)}
                placeholder="0 */6 * * *"
                className="font-mono"
              />
              <div className="text-xs text-muted-foreground">Format: minute hour day month day-of-week</div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="timezone">Timezone</Label>
              <Select value={timezone} onValueChange={setTimezone}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UTC">UTC</SelectItem>
                  <SelectItem value="America/New_York">Eastern Time</SelectItem>
                  <SelectItem value="America/Chicago">Central Time</SelectItem>
                  <SelectItem value="America/Denver">Mountain Time</SelectItem>
                  <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                  <SelectItem value="Europe/London">London</SelectItem>
                  <SelectItem value="Europe/Paris">Paris</SelectItem>
                  <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button className="flex-1" disabled={!isEnabled}>
                <Play className="h-4 w-4 mr-2" />
                Save Configuration
              </Button>
              <Button variant="outline" disabled={!isEnabled}>
                Test Run
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Status and Next Run */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Schedule Status
            </CardTitle>
            <CardDescription>Current schedule status and execution information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Current Status</span>
                <Badge
                  className={
                    isEnabled
                      ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                      : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
                  }
                >
                  {isEnabled ? "Active" : "Disabled"}
                </Badge>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">Next Run Time</span>
                <div className="text-sm text-muted-foreground">
                  {isEnabled ? getNextRunTime() : "Schedule disabled"}
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">Last Run</span>
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>{lastRun.time}</span>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Success</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Processed {lastRun.recordsProcessed} records in {lastRun.duration}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">Schedule Expression</span>
                <div className="text-sm font-mono bg-muted p-2 rounded">{cronExpression}</div>
                <div className="text-xs text-muted-foreground">Runs every 6 hours</div>
              </div>
            </div>

            {!isEnabled && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Scheduled sync is currently disabled. Enable it to start automatic synchronization.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Retry Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Retry Configuration
            </CardTitle>
            <CardDescription>Configure retry behavior for failed sync operations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="retryAttempts">Maximum Retry Attempts</Label>
              <Input
                id="retryAttempts"
                type="number"
                value={retryAttempts}
                onChange={(e) => setRetryAttempts(e.target.value)}
                min="0"
                max="10"
              />
              <div className="text-xs text-muted-foreground">Number of times to retry failed operations (0-10)</div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="retryDelay">Retry Delay (minutes)</Label>
              <Input
                id="retryDelay"
                type="number"
                value={retryDelay}
                onChange={(e) => setRetryDelay(e.target.value)}
                min="1"
                max="60"
              />
              <div className="text-xs text-muted-foreground">Time to wait between retry attempts (1-60 minutes)</div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notifications">Notification Settings</Label>
              <Textarea
                id="notifications"
                placeholder="Enter email addresses for failure notifications (comma-separated)"
                className="min-h-[80px]"
              />
            </div>

            <Button className="w-full">Update Retry Settings</Button>
          </CardContent>
        </Card>

        {/* Manual Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Manual Controls</CardTitle>
            <CardDescription>Manually trigger sync operations and manage the schedule</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full bg-transparent" variant="outline">
              <Play className="h-4 w-4 mr-2" />
              Run Sync Now
            </Button>

            <Button className="w-full bg-transparent" variant="outline">
              <Pause className="h-4 w-4 mr-2" />
              Pause Schedule
            </Button>

            <div className="pt-4 border-t">
              <h4 className="text-sm font-medium mb-2">Quick Actions</h4>
              <div className="space-y-2">
                <Button variant="ghost" className="w-full justify-start text-sm">
                  View Execution History
                </Button>
                <Button variant="ghost" className="w-full justify-start text-sm">
                  Download Configuration
                </Button>
                <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                  Reset to Defaults
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
