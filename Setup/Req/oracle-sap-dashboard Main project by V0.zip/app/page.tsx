"use client"

import { useState } from "react"
import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/app-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { OverviewTab } from "@/components/overview-tab"
import { DataViewTab } from "@/components/data-view-tab"
import { LogsTab } from "@/components/logs-tab"
import { ScheduleTab } from "@/components/schedule-tab"
import { SidebarInset } from "@/components/ui/sidebar"

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const renderActiveTab = () => {
    switch (activeTab) {
      case "overview":
        return <OverviewTab />
      case "data":
        return <DataViewTab />
      case "logs":
        return <LogsTab />
      case "schedule":
        return <ScheduleTab />
      default:
        return <OverviewTab />
    }
  }

  return (
    <SidebarProvider defaultOpen={true}>
      <AppSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <SidebarInset>
        <DashboardHeader />
        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">{renderActiveTab()}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
